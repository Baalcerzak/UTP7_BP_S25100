/**
 *
 *  @author Balcerzak Piotr S25100
 *
 */

package zad1;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;

public class Main {
    public int suma = 0;
    ExecutorService executor = Executors.newFixedThreadPool(2);
  public static void main(String[] args) throws IOException, InterruptedException {
      String fileName = "Towary.txt";
      Main main = new Main();
      main.readFile(fileName);
      /*
      FileWriter fileWriter = new FileWriter(fileName);
      PrintWriter printWriter = new PrintWriter(fileWriter);
      for(int id =0; id<10002; id++){
          int waga = (id+1) *5;
          printWriter.printf("%d %d\n", id, waga);
      }
      printWriter.close();*/


  }
  private void readFile(String fileName) throws IOException, InterruptedException {
        File myObj = new File(fileName);
        Scanner myReader = new Scanner(myObj);
        Towar towar = null;

        while (myReader.hasNextLine()) {
            String data = myReader.nextLine();
            String[] splitter = data.split(" ");
            String id = splitter[0];
            String waga = splitter[1];
            towar = new Towar(id, waga);

        }
        myReader.close();
  }

}
