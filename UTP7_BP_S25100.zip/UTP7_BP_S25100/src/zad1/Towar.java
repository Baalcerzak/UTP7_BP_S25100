package zad1;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.StampedLock;

public class Towar {

    public String waga;
    public String id;
    private static int objectCounter = 0;
    private static int objectCounter2 = 0;
    private static int sumCounter = 0;
    private static StampedLock lock = new StampedLock();
    ExecutorService executor = Executors.newFixedThreadPool(2);

    public Towar(String id, String waga) throws InterruptedException {
        this.waga = waga;
        this.id = id;
        executor.submit(()->{
            this.checkCounter();
        });
        executor.submit(()->{
            try {
                this.getSum();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
    }
    public void checkCounter(){
        long stamp = lock.writeLock();
        try {
            objectCounter++;
            if(objectCounter%200 == 0){
                        System.out.println("utworzono "+objectCounter +" obiektów");
                }
        } finally {
            lock.unlockWrite(stamp);
        }
    }

    public String getSum() throws InterruptedException {
        long stamp = lock.readLock();
        try {
            sumCounter+=Integer.parseInt(waga);
            objectCounter2++;
            if(objectCounter2%100 == 0){
                System.out.println("policzono wage "+objectCounter2 +" towarów");
            }
            return waga;
        } finally {
            lock.unlockRead(stamp);
        }
    }


}
